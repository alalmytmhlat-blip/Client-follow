"""
تهيئة مشروع أندرويد المولَّد قبل البناء. يُستدعى هكذا:  python3 patch_gradle.py build_app
1) تفعيل core library desugaring لتطبيق الإشعارات.
2) رفع compileSdk لمكتبات الإضافات (plugins) إلى نفس مستوى التطبيق.
   (المكتبات القديمة تحدد compileSdk أقل، فتفشل مع androidx الحديثة)
   يُعدَّل فقط android/build.gradle[.kts] لكل إضافة، ولا تُمسّ مجلدات example.
3) ضبط gradle.properties.
لا يُنهي البناء بخطأ بسبب شيء غير حرج: يطبع تحذيرًا ويكمل.
"""
import glob
import json
import os
import re
import sys

d = sys.argv[1]


def read(p):
    with open(p, encoding='utf-8', errors='replace') as f:
        return f.read()


def write(p, s):
    with open(p, 'w', encoding='utf-8') as f:
        f.write(s)


# ---------- 1) desugaring في التطبيق ----------
kts = os.path.join(d, 'android/app/build.gradle.kts')
grv = os.path.join(d, 'android/app/build.gradle')
DESUGAR = '2.1.4'
if os.path.exists(kts):
    s = read(kts)
    if 'isCoreLibraryDesugaringEnabled' not in s:
        if 'compileOptions {' in s:
            s = s.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
        else:
            s = re.sub(r'\bandroid\s*\{', 'android {\n    compileOptions {\n        isCoreLibraryDesugaringEnabled = true\n    }', s, count=1)
        s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:%s")\n}\n' % DESUGAR
    write(kts, s)
elif os.path.exists(grv):
    s = read(grv)
    if 'coreLibraryDesugaringEnabled' not in s:
        if 'compileOptions {' in s:
            s = s.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
        else:
            s = re.sub(r'\bandroid\s*\{', 'android {\n    compileOptions {\n        coreLibraryDesugaringEnabled true\n    }', s, count=1)
        s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:%s'\n}\n" % DESUGAR
    write(grv, s)
else:
    sys.exit('app build.gradle not found')


# ---------- 2) compileSdk للإضافات ----------
def detect_target():
    root = os.environ.get('FLUTTER_ROOT', '')
    found = []
    if root:
        pat = os.path.join(root, 'packages/flutter_tools/gradle/**/FlutterExtension.*')
        for p in glob.glob(pat, recursive=True):
            m = re.search(r'compileSdkVersion[^=\n]*=\s*(\d+)', read(p))
            if m:
                found.append(int(m.group(1)))
    return max(found) if found else 36


target = detect_target()
deps = os.path.join(d, '.flutter-plugins-dependencies')
patched = []
if os.path.exists(deps):
    info = json.loads(read(deps))
    for pl in info.get('plugins', {}).get('android', []):
        base = os.path.join(pl.get('path', ''), 'android')
        for name in ('build.gradle', 'build.gradle.kts'):
            f = os.path.join(base, name)
            if not os.path.isfile(f):
                continue
            s = read(f)

            def bump(m):
                return m.group(1) + str(target) if int(m.group(2)) < target else m.group(0)

            n = re.sub(r'(compileSdk(?:Version)?\s*=?\s*)(\d+)', bump, s)
            if n != s:
                write(f, n)
                patched.append(f)
else:
    print('WARNING: .flutter-plugins-dependencies not found (run flutter pub get first)')
print('plugins compileSdk target = %d, files patched: %d' % (target, len(patched)))
for f in patched:
    print('  -', f)

# ---------- 3) gradle.properties ----------
gp = os.path.join(d, 'android/gradle.properties')
props = read(gp) if os.path.exists(gp) else ''
if not props.endswith('\n'):
    props += '\n'
for line in ('kotlin.jvm.target.validation.mode=IGNORE',
             'android.suppressUnsupportedCompileSdk=%d' % target):
    if line.split('=')[0] not in props:
        props += line + '\n'
write(gp, props)
print('gradle ready')
