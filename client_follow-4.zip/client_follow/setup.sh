#!/usr/bin/env bash
# يبني مشروع أندرويد كامل من الشيفرة المصدرية ثم ينتج ملف APK
set -euo pipefail
cd "$(dirname "$0")"
export FLUTTER_ROOT="${FLUTTER_ROOT:-$(dirname "$(dirname "$(readlink -f "$(command -v flutter)")")")}"

rm -rf build_app
flutter create --platforms=android --org com.alalamiya --project-name client_follow build_app
rm -rf build_app/lib build_app/test build_app/analysis_options.yaml
cp -r lib build_app/lib
cp pubspec.yaml build_app/pubspec.yaml
cp android_overrides/AndroidManifest.xml build_app/android/app/src/main/AndroidManifest.xml
cp -r android_overrides/res/. build_app/android/app/src/main/res/

cd build_app
flutter pub get                      # مطلوب قبل التعديل: ينتج قائمة الإضافات
python3 ../patch_gradle.py .

# فحص الشيفرة أولًا: أي خطأ برمجي يظهر هنا خلال ثوانٍ بدل نهاية بناء Gradle
flutter analyze --no-fatal-infos --no-fatal-warnings

FLAGS=""
if flutter build apk --help | grep -q -- 'shrink'; then FLAGS="--no-shrink"; fi
flutter build apk --release $FLAGS
echo "APK: $(pwd)/build/app/outputs/flutter-apk/app-release.apk"
