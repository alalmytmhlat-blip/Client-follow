import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

/// كل دوال هذا الصف آمنة: أي فشل في الإشعارات لا يوقف التطبيق
class Notifs {
  static final _p = FlutterLocalNotificationsPlugin();

  static const _details = NotificationDetails(
    android: AndroidNotificationDetails(
      'followups',
      'مواعيد المتابعة',
      channelDescription: 'تذكيرات مواعيد التواصل مع العملاء',
      importance: Importance.max,
      priority: Priority.high,
    ),
  );

  static Future<void> init() async {
    try {
      await _p.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@drawable/ic_stat_notify'),
      ));
    } catch (_) {
      // الأيقونة الاحتياطية: أيقونة التطبيق نفسها
      await _p.initialize(const InitializationSettings(
        android: AndroidInitializationSettings('@mipmap/ic_launcher'),
      ));
    }
    final a = _p.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    // بدون await: نافذة الإذن لا يجوز أن تؤخر فتح التطبيق
    a?.requestNotificationsPermission().catchError((_) => null);
  }

  static Future<void> schedule(
      int id, String title, String body, DateTime at) async {
    if (!at.isAfter(DateTime.now())) return;
    try {
      final t = tz.TZDateTime.fromMillisecondsSinceEpoch(
          tz.UTC, at.millisecondsSinceEpoch);
      try {
        await _p.zonedSchedule(
          id, title, body, t, _details,
          androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
      } catch (_) {
        await _p.zonedSchedule(
          id, title, body, t, _details,
          androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
          uiLocalNotificationDateInterpretation:
              UILocalNotificationDateInterpretation.absoluteTime,
        );
      }
    } catch (_) {}
  }

  static Future<void> cancel(int id) async {
    try {
      await _p.cancel(id);
    } catch (_) {}
  }

  static Future<void> cancelAll() async {
    try {
      await _p.cancelAll();
    } catch (_) {}
  }

  static Future<void> showNow(String title, String body) async {
    try {
      await _p.show(2147483000, title, body, _details);
    } catch (_) {}
  }
}
