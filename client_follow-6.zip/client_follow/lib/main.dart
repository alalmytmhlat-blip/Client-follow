import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'data.dart';
import 'notifications.dart';
import 'ui.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // نعرض الواجهة فورًا؛ التهيئة تتم بعدها مع شاشة تحميل ومعالجة للأخطاء
  runApp(const ClientFollowApp());
}

Future<void> _bootstrap() async {
  await initializeDateFormatting();
  await Repo.i.init();
  // الإشعارات لا يجوز أن توقف التطبيق إن فشلت
  try {
    await Notifs.init().timeout(const Duration(seconds: 8));
  } catch (_) {}
  try {
    await Repo.i.rescheduleAll().timeout(const Duration(seconds: 8));
  } catch (_) {}
}

class ClientFollowApp extends StatelessWidget {
  const ClientFollowApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'متابع العملاء',
      debugShowCheckedModeBanner: false,
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF0B6E79)),
      ),
      home: const Bootstrap(),
    );
  }
}

class Bootstrap extends StatefulWidget {
  const Bootstrap({super.key});
  @override
  State<Bootstrap> createState() => _BootstrapState();
}

class _BootstrapState extends State<Bootstrap> {
  late Future<void> _f = _bootstrap();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<void>(
      future: _f,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        if (snap.hasError) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.error_outline, size: 48),
                    const SizedBox(height: 12),
                    const Text('تعذّر تشغيل التطبيق'),
                    const SizedBox(height: 8),
                    Text('${snap.error}', textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    FilledButton(
                      onPressed: () => setState(() => _f = _bootstrap()),
                      child: const Text('إعادة المحاولة'),
                    ),
                  ],
                ),
              ),
            ),
          );
        }
        return const HomeShell();
      },
    );
  }
}
