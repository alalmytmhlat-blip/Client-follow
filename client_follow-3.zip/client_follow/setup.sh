#!/usr/bin/env bash
# يبني مشروع أندرويد كامل من الشيفرة المصدرية ثم ينتج ملف APK
set -euo pipefail
cd "$(dirname "$0")"
rm -rf build_app
flutter create --platforms=android --org com.alalamiya --project-name client_follow build_app
rm -rf build_app/lib build_app/test build_app/analysis_options.yaml
cp -r lib build_app/lib
cp pubspec.yaml build_app/pubspec.yaml
cp android_overrides/AndroidManifest.xml build_app/android/app/src/main/AndroidManifest.xml
cp -r android_overrides/res/. build_app/android/app/src/main/res/
python3 patch_gradle.py build_app
cd build_app
flutter pub get
# فحص الشيفرة أولًا: أي خطأ برمجي يظهر هنا خلال ثوانٍ بدل الانتظار لنهاية بناء Gradle
flutter analyze --no-fatal-infos --no-fatal-warnings
flutter build apk --release --no-shrink
echo "APK: $(pwd)/build/app/outputs/flutter-apk/app-release.apk"
